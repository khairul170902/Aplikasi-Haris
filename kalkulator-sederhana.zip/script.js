function jumlahkan() {
  const angka1 = parseFloat(document.getElementById("angka1").value);
  const angka2 = parseFloat(document.getElementById("angka2").value);
  const hasil = angka1 + angka2;
  document.getElementById("hasil").textContent = isNaN(hasil) ? "Masukkan angka valid" : hasil;
}